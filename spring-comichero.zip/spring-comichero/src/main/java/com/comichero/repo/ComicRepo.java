package com.comichero.repo;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.comichero.bean.LoginBean;
import com.comichero.entity.Option;
import com.comichero.entity.Quiz;
import com.comichero.entity.User;

public interface ComicRepo {
	
	Boolean authenticate(LoginBean login);
	
	boolean persist(User user);
	
	List<Quiz> fetchAllQuiz();
	
	String identifyHero(HttpServletRequest request);
	

}
