package com.comichero.repo;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.comichero.bean.LoginBean;
import com.comichero.entity.Option;
import com.comichero.entity.Quiz;
import com.comichero.entity.User;

@Repository // stereotype annotation
@Transactional // to create proxy (proxy are used for spring to inject behaviour.)
public class ComicRepoImpl implements ComicRepo {

	@Autowired
	private SessionFactory factory;

	public Boolean authenticate(LoginBean login) { // method for login
		Session session = factory.getCurrentSession();
		try {

			User user = (User) session.get(User.class, login.getEmailId());
			if (user != null && user.getPassword().equals(login.getPassword()))
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	public boolean persist(User user) { // method for register user

		try {
			Session session = factory.getCurrentSession();
			session.save(user);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public List<Quiz> fetchAllQuiz() { // method for fetching the quiz and option
		Session session = factory.getCurrentSession(); // creating session
		List<Quiz> quiz = session.createQuery("from Quiz").list(); // Retriving all the quiz table details and storing
																	// it in "quiz" object

		return quiz;
	}

	public String identifyHero(HttpServletRequest request) { //method of implementation for selected option from the user
		String hero = null;
		int batman = 0, superman = 0, spiderman = 0, ironman = 0;
		Map<String, String[]> param = request.getParameterMap(); 		

		for (String key : param.keySet()) {
			System.out.println(key + " - " + Arrays.toString(param.get(key))); //selected option is stored here in the form of string
			int num = Integer.parseInt(param.get(key)[0]); // string is converted into int and it is stored in num variable
				
			// logic for identifying the superhero
			if (num == 2 || num == 3 || num == 7 || num == 8 || num == 10 || num == 13 || num == 18 || num == 21
					|| num == 31 || num == 34) {
				batman++;
			} else if (num == 1 || num == 5 || num == 9 || num == 14 || num == 17 || num == 23 || num == 29 || num == 32
					|| num == 35) {
				spiderman++;
			}

			else if (num == 11 || num == 20 || num == 24 || num == 30 || num == 33 || num == 6 || num == 16
					|| num == 25) {
				superman++;

			} else if (num == 4 || num == 15 || num == 19 || num == 22 || num == 28 || num == 12 || num == 26
					|| num == 27) {

				ironman++;
			}

		}

		if (batman > spiderman && batman > superman && batman > ironman) {
			hero = "batman";
			return hero;
		} else if (spiderman > batman && spiderman > ironman && spiderman > superman) {
			hero = "spiderman";
			return hero;
		} else if (superman > batman && superman > ironman && superman > spiderman) {
			hero = "superman";
			return hero;
		} else if (ironman > batman && ironman > superman && ironman > spiderman) {

			hero = "ironman";
			return hero;
		}

		return hero;

	}
}
