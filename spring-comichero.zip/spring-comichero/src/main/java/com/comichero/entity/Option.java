package com.comichero.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "option") // in comichero database creating a table name called "option"
public class Option {
	@Id
	@Column(name = "opt_id") // created it as a primary key
	private int optId;

	@ManyToOne
	@JoinColumn(name = "q_Id") // many to one relation between option and quiz
	private Quiz quiz;

	private String option;

	public int getOptId() {
		return optId;
	}

	public void setOptId(int optId) {
		this.optId = optId;
	}

	public Quiz getQuiz() {
		return quiz;
	}

	public void setQuiz(Quiz quiz) {
		this.quiz = quiz;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

}
