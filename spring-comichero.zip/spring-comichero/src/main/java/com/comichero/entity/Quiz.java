package com.comichero.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="quiz") // in comichero database creating a table name called "quiz"
public class Quiz {

	@Id
	@Column(name="q_id")			//created it as a primary key
			
	private int qId;
	
	private String question;
	     
	@OneToMany(mappedBy="quiz", fetch=FetchType.EAGER)  //one to many relationship between quiz and option. EAGER instantiation means fetching/loads all the relationship bydeafult its LAZY but its doesnot loads all relationship unless it is invoked
	private Set<Option> option;

	
	//getters and setters
	public int getqId() {
		return qId;
	}

	public void setqId(int qId) {
		this.qId = qId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Set<Option> getOption() {
		return option;
	}

	public void setOption(Set<Option> option) {
		this.option = option;
	}
	
	
	
	
	
}
