package com.comichero.web;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.comichero.bean.LoginBean;
import com.comichero.entity.Option;
import com.comichero.entity.Quiz;
import com.comichero.entity.User;
import com.comichero.repo.ComicRepo;

@Controller
public class ComicheroController {

	@Autowired
	private ComicRepo repo;

	@RequestMapping(value = "/login.go", method = RequestMethod.POST)
	public String authenticate(LoginBean login, Map model, HttpSession session) {
		Boolean user = repo.authenticate(login);
		List<Quiz> quiz = repo.fetchAllQuiz();
		if (user) {
			session.setAttribute("Result", quiz);
			return "quiz";
		} else {
			model.put("Alert", "Invalid Email Id/Password");
			return "home";
		}
	}

	@RequestMapping(value = "/register.go", method = RequestMethod.POST)
	public String persist(User user, Map model) {
		if (repo.persist(user)) {
			model.put("Alert", "Thank you for registration");
			return "home";
		} else {
			model.put("Alert", "User exist with same Email ID");
			return "register";
		}
	}
	
	@RequestMapping(value = "/quiz.go", method = RequestMethod.POST)
	public String indentifyHero(HttpServletRequest request) {
		
		String hero=repo.identifyHero(request);
		request.setAttribute("result", hero);
		return "show";
	}
	
	@RequestMapping("/logout.go")
	public String logout(Map model , HttpSession session) {
		session.removeAttribute("User");
		session.invalidate();
		model.put("Alert", "logged out succesfully");
		return "home";	
	}

}
