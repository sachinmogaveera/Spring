package com.comichero.bean;

public class LoginBean {

	
	private String emailId;
	private String password;
	
	// getter and setter for email and password
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
}
